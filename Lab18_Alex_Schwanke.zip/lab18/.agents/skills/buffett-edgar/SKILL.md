---
name: buffett-edgar
description: Evaluate a company's business using the Lab 18 Buffett checks on five years of SEC EDGAR 10-K facts, then write an evidence-bound business memo.
---

Run the bundled script from the project root:

```powershell
python .agents/skills/buffett-edgar/scripts/edgar.py COST --out reports
```

Live downloads require `SEC_USER_AGENT` containing the caller's name and email. Ask for it if absent; do not invent contact details. Do not put contact information into reports.

The script prints and saves the last five annual periods, source tags, filing dates, accessions, raw facts, calculated ROE, owner earnings, and three checks. Read its printed report before writing a memo. Use only numbers it printed, in the same units and meaning. Do not calculate additional numbers in prose. Preserve `not found` for absent facts and `not known` for checks with absent inputs or ROE with nonpositive equity.

Write `reports/TICKER_memo.md`: choose **own the business**, **watch**, or **pass**; explain earning power, consistency, and what remains uncertain. Use Buffett's circle-of-competence, durable-advantage, and owner-earnings perspective as a lens, not impersonation or a claim that Buffett endorsed the company. Separate evidence from judgment. The limited financial screen does not establish moat durability or management quality. No prices, targets, forecasts, intrinsic values, or paid data. Owner earnings here means operating cash flow minus total capital spending, the lab's proxy rather than an estimate of maintenance spending.

Run the number guard after saving:

```powershell
python .agents/skills/buffett-edgar/scripts/edgar.py --validate-memo reports/COST_memo.md --report reports/COST.json
```

Fix unsupported numbers. The guard checks numeric support, not whether a supported number was assigned to the right financial concept; review those meanings yourself. A changed report requires reviewing the memo again.

Validate COST against `reference/cost_lab_reference.json`; report discrepancies rather than changing SEC facts to fit. Probe JPM's missing capex, and add an unsupported ROE to a temporary memo to prove the guard flags it. Run `python -m streamlit run app.py` to display the chart, table, checks, evidence, and editable memo.

Reference philosophy: https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md
Reference architecture: https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/SKILL.md
The course's SEC-only and code-computes rules override that reference's paid APIs, price analysis, estimated maintenance capex, and full investor panel. Do not install FAskills.
