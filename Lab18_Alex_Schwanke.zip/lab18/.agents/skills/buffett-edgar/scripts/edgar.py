"""SEC-only Lab 18 calculations. Standard library; no AI or paid API calls."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import time
import sys
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

TAGS = {
    "revenue": ("RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues"),
    "net_income": ("NetIncomeLoss",),
    "operating_cash_flow": ("NetCashProvidedByUsedInOperatingActivities",),
    "capital_spending": ("PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"),
    "equity": ("StockholdersEquity",),
}
TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
FACTS_URL = "https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json"
DISCLOSURE = "Data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice."
NUMBER = re.compile(r"(?<![\w.])[-+\u2212]?(?:(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?|\.\d+)(?:[eE][-+]?\d+)?%?(?!\w)")


def fetch_json(url, user_agent):
    """Identify caller, space requests, and retry only bounded transient failures."""
    if not user_agent or "@" not in user_agent or len(user_agent.split()) < 2:
        raise ValueError("Set SEC_USER_AGENT to your name and email before downloading.")
    for attempt in range(3):
        time.sleep(0.25 + attempt)
        try:
            request = Request(url, headers={"User-Agent": user_agent, "Accept": "application/json"})
            with urlopen(request, timeout=45) as response:
                return json.load(response)
        except HTTPError as exc:
            if exc.code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise RuntimeError(f"SEC request failed ({exc.code}) at {url}. No data substituted.") from exc
        except (URLError, TimeoutError) as exc:
            if attempt == 2:
                raise RuntimeError(f"SEC request failed at {url}: {exc}. No data substituted.") from exc


def annual_fact(fact, as_of):
    """Accept USD annual 10-K flow contexts, including 52/53-week years."""
    if fact.get("form") != "10-K" or fact.get("filed", "9999") > as_of:
        return False
    try:
        days = (date.fromisoformat(fact["end"]) - date.fromisoformat(fact["start"])).days
        return 330 <= days <= 380 and isinstance(fact.get("val"), (int, float))
    except (KeyError, ValueError):
        return False


def fiscal_periods(company, as_of):
    """Use current-year annual contexts, not fy labels on comparative rows.

    `fy` describes the filing, so a prior-year comparative in a later filing
    must not be relabelled as that filing's fiscal year.
    """
    gaap = company.get("facts", {}).get("us-gaap", {})
    candidates = []
    for metric in ("revenue", "net_income", "operating_cash_flow"):
        for tag in TAGS[metric]:
            candidates.extend(f for f in gaap.get(tag, {}).get("units", {}).get("USD", []) if annual_fact(f, as_of))
    if not candidates:
        raise ValueError("No annual USD 10-K flow facts found; no periods can be established.")
    # Each annual filing contains comparatives; its latest annual end is its own FY end.
    by_accession = {}
    for fact in candidates:
        accession = fact.get("accn", fact.get("filed", ""))
        by_accession[accession] = max(by_accession.get(accession, ""), fact["end"])
    ends = sorted(set(by_accession.values()))[-5:]
    periods = []
    for end in ends:
        options = [f for f in candidates if f["end"] == end]
        latest = max(options, key=lambda f: (f.get("filed", ""), f.get("accn", "")))
        periods.append((latest["start"], end))
    return periods


def select_fact(company, metric, start, end, as_of):
    """Tag priority applies per fiscal period; latest eligible filing wins."""
    gaap = company.get("facts", {}).get("us-gaap", {})
    for tag in TAGS[metric]:
        options = []
        for fact in gaap.get(tag, {}).get("units", {}).get("USD", []):
            if fact.get("end") != end or fact.get("form") != "10-K" or fact.get("filed", "9999") > as_of:
                continue
            if not isinstance(fact.get("val"), (int, float)):
                continue
            if metric == "equity":
                if fact.get("start"):
                    continue
            elif not annual_fact(fact, as_of) or fact["start"] != start:
                continue
            options.append(fact)
        if options:
            fact = max(options, key=lambda f: (f.get("filed", ""), f.get("accn", "")))
            return {"value": fact["val"], "tag": "us-gaap:" + tag, "filed": fact.get("filed"),
                    "accession": fact.get("accn"), "start": fact.get("start"), "end": end, "unit": "USD"}
    return {"value": None, "tag": "not found", "attempted_tags": ["us-gaap:" + t for t in TAGS[metric]],
            "status": "not found", "unit": "USD"}


def build_row(company, start, end, as_of):
    """Turn facts into one annual row. Missing inputs stay missing."""
    sources = {metric: select_fact(company, metric, start, end, as_of) for metric in TAGS}
    row = {"fiscal_year_end": end, "period_start": start, "sources": sources}
    row.update({metric: source["value"] for metric, source in sources.items()})
    income, equity = row["net_income"], row["equity"]
    ocf, capex = row["operating_cash_flow"], row["capital_spending"]
    row["roe_pct"] = income / equity * 100 if income is not None and equity is not None and equity > 0 else None
    row["owner_earnings"] = ocf - capex if ocf is not None and capex is not None else None
    row["roe_status"] = "known" if row["roe_pct"] is not None else "not known"
    row["owner_earnings_status"] = "known" if row["owner_earnings"] is not None else "not found"
    return row


def checks(rows):
    def every(key, predicate):
        values = [r[key] for r in rows]
        if len(values) != 5 or any(v is None for v in values):
            return "not known"
        return "pass" if all(predicate(v) for v in values) else "fail"
    owner = [r["owner_earnings"] for r in rows]
    return {
        "ROE at least 15% every year": every("roe_pct", lambda v: v >= 15),
        "Owner earnings positive every year": every("owner_earnings", lambda v: v > 0),
        "Owner earnings grew first year to last": "not known" if len(owner) != 5 or any(v is None for v in owner)
        else ("pass" if owner[-1] > owner[0] else "fail"),
    }


def analyze(company, ticker, as_of, provenance):
    rows = [build_row(company, start, end, as_of) for start, end in fiscal_periods(company, as_of)]
    return {"ticker": ticker.upper(), "company": company.get("entityName", "Unknown company"),
            "cik": company.get("cik"), "as_of": as_of, "provenance": provenance,
            "units": "USD millions; ROE in percent", "rows": rows, "checks": checks(rows)}


def formatted(value, percent=False):
    if value is None:
        return "not known" if percent else "not found"
    return f"{value:.1f}%" if percent else f"{value / 1_000_000:,.3f}".rstrip("0").rstrip(".")


def render_report(report):
    lines = [f"# {report['ticker']} — Buffett business screen", "", report["company"], "",
             f"As of {report['as_of']}. {report['units']}.", "",
             "| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE | Owner earnings |",
             "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for row in report["rows"]:
        values = [formatted(row[key], key == "roe_pct") for key in (*TAGS, "roe_pct", "owner_earnings")]
        lines.append("| " + " | ".join([row["fiscal_year_end"], *values]) + " |")
    lines += ["", "## Computed checks", ""]
    lines += [f"- {label}: **{status}**" for label, status in report["checks"].items()]
    lines += ["", "## Source ledger", "", "| Fiscal year end | Metric | USD raw | XBRL tag / formula | Filing date | Accession |", "|---|---|---:|---|---|---|"]
    for row in report["rows"]:
        for metric, fact in row["sources"].items():
            lines.append(f"| {row['fiscal_year_end']} | {metric} | {fact['value'] if fact['value'] is not None else 'not found'} | {fact['tag']} | {fact.get('filed', '')} | {fact.get('accession', '')} |")
        lines.append(f"| {row['fiscal_year_end']} | roe_pct | {formatted(row['roe_pct'], True)} | NetIncomeLoss / StockholdersEquity × 100 | calculated | |")
        lines.append(f"| {row['fiscal_year_end']} | owner_earnings | {row['owner_earnings'] if row['owner_earnings'] is not None else 'not found'} | operating_cash_flow − capital_spending (source tags above) | calculated | |")
    lines += ["", "ROE uses year-end equity; nonpositive equity makes ROE not known.",
              "Owner earnings uses total capital spending, not estimated maintenance spending.",
              "Threshold rationale: the course's 15% ROE floor screens persistent profitability; positive and growing owner earnings screen cash generation. These are design choices, not a valuation.",
              "Missing input makes a check not known. No values are estimated.", "", DISCLOSURE, ""]
    return "\n".join(lines)


def numeric_key(token):
    percent = token.endswith("%")
    try:
        value = Decimal(token.rstrip("%").replace(",", "").replace("\u2212", "-"))
        return value.normalize(), percent
    except InvalidOperation:
        return token, percent


def unsupported_numbers(memo, printed):
    """Exact decimal value + percent-unit support; return occurrence and line."""
    allowed = {numeric_key(m.group()) for m in NUMBER.finditer(printed)}
    return [{"token": m.group(), "line": memo.count("\n", 0, m.start()) + 1}
            for m in NUMBER.finditer(memo) if numeric_key(m.group()) not in allowed]


def save_report(report, out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    stem = out / report["ticker"]
    stem.with_suffix(".json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    text = render_report(report)
    stem.with_suffix(".md").write_text(text, encoding="utf-8")
    keys = [*TAGS, "roe_pct", "owner_earnings"]
    with stem.with_suffix(".csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["fiscal_year_end", *[k + ("_percent" if k == "roe_pct" else "_USD") for k in keys]])
        for row in report["rows"]:
            writer.writerow([row["fiscal_year_end"], *[row[k] if row[k] is not None else ("not known" if k == "roe_pct" else "not found") for k in keys]])
    return text


def download(ticker, user_agent, cache_dir):
    ticker = ticker.upper().strip()
    if not re.fullmatch(r"[A-Z0-9.-]{1,12}", ticker):
        raise ValueError("Enter a valid ticker, such as COST or JPM.")
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    mapping = fetch_json(TICKERS_URL, user_agent)
    match = next((entry for entry in mapping.values() if entry["ticker"].upper() == ticker), None)
    if match is None:
        raise ValueError(f"Ticker {ticker} not found in SEC ticker map.")
    url = FACTS_URL.format(cik=int(match["cik_str"]))
    company = fetch_json(url, user_agent)
    raw = json.dumps(company, sort_keys=True).encode()
    path = cache_dir / f"{ticker}_companyfacts.json"
    path.write_bytes(raw)
    provenance = {"kind": "live SEC download", "source_url": url,
                  "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                  "sha256": hashlib.sha256(raw).hexdigest()}
    path.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2), encoding="utf-8")
    return company, provenance


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ticker", nargs="?", default="COST")
    parser.add_argument("--out", default="reports")
    parser.add_argument("--as-of", default=date.today().isoformat())
    parser.add_argument("--facts", type=Path, help="Use an explicitly supplied SEC companyfacts JSON snapshot")
    parser.add_argument("--validate-memo", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    date.fromisoformat(args.as_of)
    if args.validate_memo:
        if not args.report:
            parser.error("--report is required with --validate-memo")
        report = json.loads(args.report.read_text(encoding="utf-8"))
        flags = unsupported_numbers(args.validate_memo.read_text(encoding="utf-8"), render_report(report))
        print(json.dumps({"unsupported_numbers": flags}, indent=2))
        return 1 if flags else 0
    if args.facts:
        raw = args.facts.read_bytes()
        company = json.loads(raw)
        sidecar = args.facts.with_suffix(".provenance.json")
        provenance = json.loads(sidecar.read_text(encoding="utf-8")) if sidecar.exists() else {"kind": "user-supplied snapshot", "sha256": hashlib.sha256(raw).hexdigest()}
        if provenance.get("sha256") != hashlib.sha256(raw).hexdigest():
            raise ValueError("Snapshot hash does not match its provenance record.")
    else:
        company, provenance = download(args.ticker, os.getenv("SEC_USER_AGENT", ""), Path(args.out) / "raw")
    report = analyze(company, args.ticker, args.as_of, provenance)
    print(save_report(report, args.out))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, RuntimeError) as error:
        raise SystemExit(str(error))
