# Lab 18 — Buffett Business Lens

Completed locally for Alex Schwanke on November 3, 2026. Nothing was uploaded to GitHub or submitted to Brightspace.

## Open the app

Run `run.ps1` in PowerShell. It finds a working Python, creates a local virtual environment if necessary, installs the app dependencies, and launches Streamlit on localhost. The saved COST and JPM reports work without another download. You can also use:

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

The ticker accepts another SEC-listed company. Live downloads need the caller's name and email in the app's masked contact field or in the process-only `SEC_USER_AGENT` environment variable. Contact details are not saved in the package.

## Use the skill

Open this `lab18` folder as the project in Codex/VS Code. The project skill is `.agents/skills/buffett-edgar/SKILL.md`. In a new chat ask: “Use $buffett-edgar on COST; read its printed evidence, write a business-only memo, and validate its numbers.” If your running chat has not discovered the new skill, start a fresh chat in this folder or explicitly point it to the file.

The script works with the standard library; Streamlit is needed only for the app. Example commands from this folder:

```powershell
# A downloaded snapshot can be recalculated without a network request:
python .agents/skills/buffett-edgar/scripts/edgar.py COST --facts reports/raw/COST_companyfacts.json --as-of 2026-11-03 --out reports

# Live: first set SEC_USER_AGENT to your own name and email in this shell.
python .agents/skills/buffett-edgar/scripts/edgar.py COST --as-of 2026-11-03 --out reports
python .agents/skills/buffett-edgar/scripts/edgar.py JPM --as-of 2026-11-03 --out reports

# Check the AI-authored memo:
python .agents/skills/buffett-edgar/scripts/edgar.py --validate-memo reports/COST_memo.md --report reports/COST.json

# Repeat verification without downloading:
python verify.py
```

The report retains raw USD values and presents the main table in USD millions. Each input has a tag, period, filing date, and accession. Raw companyfacts snapshots and SHA-256 records are in `reports/raw/`. A cutoff applies to filing dates, and the latest eligible filing for the same annual period wins. Annual flow contexts must be 330–380 days; quarterly contexts cannot enter the annual calculations. The annual-period window accommodates fiscal calendars and 52/53-week years, rather than using a filing's `fy` field to relabel its comparative observations.

## Deliverables

| File | Purpose |
|---|---|
| `.agents/skills/buffett-edgar/SKILL.md` | Discoverable Buffett workflow and bundled script instructions |
| `.agents/skills/buffett-edgar/scripts/edgar.py` | SEC downloader, period selection, calculations, evidence printing, memo guard |
| `app.py` | Streamlit ticker input, chart, table, checks, editable memo and unsupported-number flags |
| `reports/COST.md`, `reports/JPM.md` | Printed calculations and source ledgers |
| `reports/COST_memo.md`, `reports/JPM_memo.md` | AI-authored judgments using printed numbers only |
| `reports/*.json`, `reports/*.csv` | Machine-readable report and financial table |
| `VALIDATION.md` | Recorded verification results |
| `LEARNING_NOTES.md` | Explanations, reflection draft, and remaining in-class activities |
| `BUILD_REQUEST.md` | Reusable lab-specific build request |
| `reference/cost_lab_reference.json` | Independent course answer, used only for checking |

## What remains for the student

The local coding and evidence package is complete. You still need to personally do the no-AI partner explanation and discussions; review the proposed trust decision and reflection; and complete your individual Brightspace checkout. The lab asks for GitHub links, but you explicitly requested no posting. This package therefore contains local files only, and cannot provide published GitHub checkout links. The fresh-chat comparison is recorded from the output Alex supplied. No quiz or partner activity is represented as completed.

## Source adaptation

Read as references, without installing FAskills:

- [Lab 18](https://github.com/CinderZhang/FIN43900-Fall2026/blob/main/lessons/week-11/lab-18-legend-investor-as-skill.md)
- [FAskills financial-researcher SKILL.md](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/SKILL.md)
- [Buffett expert page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md)
- [SEC API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces)
- [Codex skills documentation](https://developers.openai.com/codex/skills)

FAskills' relevant architecture is to calculate metrics in Python before an expert model judges them, then validate the output. This lab keeps that separation and a Buffett lens. Its explicit five-year, SEC-only, business-only requirements replace paid providers, price targets, estimated maintenance capex, broader scores, and a multi-investor panel. This package is an original lab implementation, not an installation of the FAskills plugin.

## Limits

The guard verifies numeric tokens against the printed report, including percentage units. It cannot prove a supported number is attached to the right concept or that qualitative claims are true. The model must review those meanings. The memo is authored in the AI chat and saved to Markdown; the app has no paid model integration and never substitutes a rule-generated verdict for model judgment. Downloading new facts does not automatically rewrite an older memo. Check the saved report's cutoff and provenance and review the memo after refresh.

