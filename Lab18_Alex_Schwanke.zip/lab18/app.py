"""Run: python -m streamlit run app.py"""
import importlib.util
import json
import os
from pathlib import Path
from datetime import date

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("edgar", ROOT / ".agents/skills/buffett-edgar/scripts/edgar.py")
edgar = importlib.util.module_from_spec(spec)
spec.loader.exec_module(edgar)

st.set_page_config(page_title="Buffett Business Lens", page_icon="📊", layout="wide")
st.title("Buffett Business Lens")
st.caption(edgar.DISCLOSURE)
st.write("Five annual filings. Three reproducible checks. One business judgment.")

with st.sidebar:
    st.header("Company")
    ticker = st.text_input("Ticker", "COST").strip().upper()
    as_of = st.date_input("Filing cutoff", date(2026, 11, 3))
    user_agent = st.text_input("SEC contact: your name and email", value=os.getenv("SEC_USER_AGENT", ""), type="password")
    fetch = st.button("Download live SEC facts", type="primary")
    st.caption("The contact is sent only to SEC for downloads and is not saved in reports.")
    st.divider()
    st.write("ROE uses year-end equity. Owner earnings = operating cash flow − total capital spending.")

if fetch:
    try:
        with st.spinner("Downloading and calculating…"):
            company, provenance = edgar.download(ticker, user_agent, ROOT / "reports/raw")
            report = edgar.analyze(company, ticker, as_of.isoformat(), provenance)
            edgar.save_report(report, ROOT / "reports")
        st.session_state[f"report_{ticker}"] = report
    except (ValueError, RuntimeError, OSError) as exc:
        st.error(str(exc))

report = st.session_state.get(f"report_{ticker}")
path = ROOT / "reports" / f"{ticker}.json"
if report is None and path.exists():
    report = json.loads(path.read_text(encoding="utf-8"))
if report is None:
    st.info("Enter SEC contact information and download a ticker to begin.")
    st.stop()

st.subheader(f"{report['company']} · {ticker}")
provenance = report["provenance"]
st.caption(f"Snapshot: {provenance.get('kind')} · Retrieved {provenance.get('retrieved_at_utc', 'unknown')} · Filing cutoff {report['as_of']}")
if report["as_of"] != as_of.isoformat():
    st.warning("The displayed saved report has a different filing cutoff. Download facts to apply the selected cutoff.")
cols = st.columns(3)
for col, (label, status) in zip(cols, report["checks"].items()):
    col.metric(label, status.upper())

frame = pd.DataFrame(report["rows"])
chart = frame.set_index("fiscal_year_end")[["owner_earnings", "net_income"]] / 1_000_000
chart.columns = ["Owner earnings", "Net income"]
st.subheader("Cash generation and accounting profit")
st.caption("USD millions; missing values remain gaps.")
st.line_chart(chart)
st.subheader("Five-year financials")
st.caption("USD millions, except ROE in percent.")
display = []
for row in report["rows"]:
    display.append({"Fiscal year end": row["fiscal_year_end"], **{
        key.replace("_", " ").title(): edgar.formatted(row[key], key == "roe_pct")
        for key in (*edgar.TAGS, "roe_pct", "owner_earnings")}})
st.dataframe(pd.DataFrame(display), hide_index=True, width="stretch")

st.subheader("Business memo")
memo_path = ROOT / "reports" / f"{ticker}_memo.md"
initial = memo_path.read_text(encoding="utf-8") if memo_path.exists() else ""
memo = st.text_area("Edit memo or insert an unsupported number to test the guard", initial, height=260, key=f"memo_{ticker}")
flags = edgar.unsupported_numbers(memo, edgar.render_report(report))
if flags:
    st.error("Unsupported numbers: " + "; ".join(f"{f['token']} (line {f['line']})" for f in flags))
elif memo.strip():
    st.success("Every numeric token has support in the printed report. Review the meaning and units too.")
else:
    st.info("Run the Buffett skill in your AI to write a memo from this ticker's printed report, then paste it here.")
if memo:
    st.markdown(memo)
st.download_button("Download edited memo", memo, file_name=f"{ticker}_memo.md", mime="text/markdown")
st.download_button("Download printed evidence", edgar.render_report(report), file_name=f"{ticker}.md", mime="text/markdown")
with st.expander("Source tags, filing accessions, and calculation evidence"):
    st.markdown(edgar.render_report(report).split("## Source ledger", 1)[1])
    st.json(provenance)
st.caption("The app displays human/AI-authored memos; it does not call a model or automatically infer a verdict from passing checks.")
