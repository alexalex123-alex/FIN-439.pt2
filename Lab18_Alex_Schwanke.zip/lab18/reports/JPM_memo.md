# JPM — Buffett-style business memo

**Verdict: watch.** This is an AI-authored Buffett-style business assessment, not a statement by Warren Buffett or a stock-price recommendation.

The latest net income is 57,048 in USD millions, and the latest ROE is 15.7%. However, ROE was 12.9% in an earlier reported year, so the persistent-return check fails.

I cannot judge owner earnings under the lab's required definition. Capital spending is not found under either permitted XBRL tag, which leaves owner earnings not found and both owner-earnings checks not known. Missing capex is not zero; replacing it with an estimate would create an unsupported conclusion.

The industrial-company cash-flow proxy is also a limited lens for a bank, where lending and funding flows affect cash movement. I would seek an appropriate banking analysis before making an ownership judgment. The absent owner-earnings evidence is a reason to withhold a verdict, not evidence that the company generates no economic earnings. No price or valuation conclusion follows from this screen.
