# JPM — Buffett business screen

JPMORGAN CHASE & CO

As of 2026-11-03. USD millions; ROE in percent.

| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2021-12-31 | 121,649 | 48,334 | 78,084 | not found | 294,127 | 16.4% | not found |
| 2022-12-31 | 128,695 | 37,676 | 107,119 | not found | 292,332 | 12.9% | not found |
| 2023-12-31 | 158,104 | 49,552 | 12,974 | not found | 327,878 | 15.1% | not found |
| 2024-12-31 | 177,556 | 58,471 | -42,012 | not found | 344,758 | 17.0% | not found |
| 2025-12-31 | 182,447 | 57,048 | -147,782 | not found | 362,438 | 15.7% | not found |

## Computed checks

- ROE at least 15% every year: **fail**
- Owner earnings positive every year: **not known**
- Owner earnings grew first year to last: **not known**

## Source ledger

| Fiscal year end | Metric | USD raw | XBRL tag / formula | Filing date | Accession |
|---|---|---:|---|---|---|
| 2021-12-31 | revenue | 121649000000 | us-gaap:Revenues | 2024-02-16 | 0000019617-24-000225 |
| 2021-12-31 | net_income | 48334000000 | us-gaap:NetIncomeLoss | 2024-02-16 | 0000019617-24-000225 |
| 2021-12-31 | operating_cash_flow | 78084000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2024-02-16 | 0000019617-24-000225 |
| 2021-12-31 | capital_spending | not found | not found |  |  |
| 2021-12-31 | equity | 294127000000 | us-gaap:StockholdersEquity | 2024-02-16 | 0000019617-24-000225 |
| 2021-12-31 | roe_pct | 16.4% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2021-12-31 | owner_earnings | not found | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2022-12-31 | revenue | 128695000000 | us-gaap:Revenues | 2025-02-14 | 0000019617-25-000270 |
| 2022-12-31 | net_income | 37676000000 | us-gaap:NetIncomeLoss | 2025-02-14 | 0000019617-25-000270 |
| 2022-12-31 | operating_cash_flow | 107119000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2025-02-14 | 0000019617-25-000270 |
| 2022-12-31 | capital_spending | not found | not found |  |  |
| 2022-12-31 | equity | 292332000000 | us-gaap:StockholdersEquity | 2025-02-14 | 0000019617-25-000270 |
| 2022-12-31 | roe_pct | 12.9% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2022-12-31 | owner_earnings | not found | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2023-12-31 | revenue | 158104000000 | us-gaap:Revenues | 2026-02-13 | 0001628280-26-008131 |
| 2023-12-31 | net_income | 49552000000 | us-gaap:NetIncomeLoss | 2026-02-13 | 0001628280-26-008131 |
| 2023-12-31 | operating_cash_flow | 12974000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2026-02-13 | 0001628280-26-008131 |
| 2023-12-31 | capital_spending | not found | not found |  |  |
| 2023-12-31 | equity | 327878000000 | us-gaap:StockholdersEquity | 2026-02-13 | 0001628280-26-008131 |
| 2023-12-31 | roe_pct | 15.1% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2023-12-31 | owner_earnings | not found | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2024-12-31 | revenue | 177556000000 | us-gaap:Revenues | 2026-02-13 | 0001628280-26-008131 |
| 2024-12-31 | net_income | 58471000000 | us-gaap:NetIncomeLoss | 2026-02-13 | 0001628280-26-008131 |
| 2024-12-31 | operating_cash_flow | -42012000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2026-02-13 | 0001628280-26-008131 |
| 2024-12-31 | capital_spending | not found | not found |  |  |
| 2024-12-31 | equity | 344758000000 | us-gaap:StockholdersEquity | 2026-02-13 | 0001628280-26-008131 |
| 2024-12-31 | roe_pct | 17.0% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2024-12-31 | owner_earnings | not found | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2025-12-31 | revenue | 182447000000 | us-gaap:Revenues | 2026-02-13 | 0001628280-26-008131 |
| 2025-12-31 | net_income | 57048000000 | us-gaap:NetIncomeLoss | 2026-02-13 | 0001628280-26-008131 |
| 2025-12-31 | operating_cash_flow | -147782000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2026-02-13 | 0001628280-26-008131 |
| 2025-12-31 | capital_spending | not found | not found |  |  |
| 2025-12-31 | equity | 362438000000 | us-gaap:StockholdersEquity | 2026-02-13 | 0001628280-26-008131 |
| 2025-12-31 | roe_pct | 15.7% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2025-12-31 | owner_earnings | not found | operating_cash_flow − capital_spending (source tags above) | calculated | |

ROE uses year-end equity; nonpositive equity makes ROE not known.
Owner earnings uses total capital spending, not estimated maintenance spending.
Threshold rationale: the course's 15% ROE floor screens persistent profitability; positive and growing owner earnings screen cash generation. These are design choices, not a valuation.
Missing input makes a check not known. No values are estimated.

Data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice.
