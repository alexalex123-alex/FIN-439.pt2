# COST — Buffett-style business memo

**Verdict: own the business.** This is an AI-authored assessment through a Buffett-style lens, not a statement by Warren Buffett or a decision about the stock's price.

I prefer a business whose accounting earnings are accompanied by cash that can remain after capital spending. All amounts below are USD millions. Costco's net income rose from 5,844 to 9,226, while the lab's owner-earnings proxy rose from 3,501 to 9,382. Owner earnings remained positive throughout the period, although the decline from 6,745 to 6,629 shows that improvement was not uninterrupted.

ROE stayed above the chosen 15% floor in every reported year, and the latest ROE was 25.8%. Revenue rose from 226,954 to 303,154. Together, persistent returns on year-end equity and positive cash generation make this a business I would be comfortable studying for long-term ownership. The checks support that judgment; they do not prove a durable competitive advantage or trustworthy capital allocation.

The main limitation is the proxy: operating cash flow minus all capital spending does not distinguish maintenance from expansion, and cash flow can move with working capital. This screen also leaves competitive durability and management quality unverified. I would revisit the verdict if cash generation weakened persistently or evidence undermined the durability of the business. No stock price, valuation, or expected return is inferred.

**Trust decision — proposed for Alex to review:** I trust the numerical screen because the code's output matches the course reference and each input has an EDGAR tag and filing accession; I treat the ownership verdict as a qualified judgment that still needs evidence about competitive advantage and management.
