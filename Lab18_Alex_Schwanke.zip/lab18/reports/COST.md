# COST — Buffett business screen

COSTCO WHOLESALE CORP /NEW

As of 2026-11-03. USD millions; ROE in percent.

| Fiscal year end | Revenue | Net income | Operating cash flow | Capital spending | Equity | ROE | Owner earnings |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2022-08-28 | 226,954 | 5,844 | 7,392 | 3,891 | 20,642 | 28.3% | 3,501 |
| 2023-09-03 | 242,290 | 6,292 | 11,068 | 4,323 | 25,058 | 25.1% | 6,745 |
| 2024-09-01 | 254,453 | 7,367 | 11,339 | 4,710 | 23,622 | 31.2% | 6,629 |
| 2025-08-31 | 275,235 | 8,099 | 13,335 | 5,498 | 29,164 | 27.8% | 7,837 |
| 2026-08-30 | 303,154 | 9,226 | 15,817 | 6,435 | 35,803 | 25.8% | 9,382 |

## Computed checks

- ROE at least 15% every year: **pass**
- Owner earnings positive every year: **pass**
- Owner earnings grew first year to last: **pass**

## Source ledger

| Fiscal year end | Metric | USD raw | XBRL tag / formula | Filing date | Accession |
|---|---|---:|---|---|---|
| 2022-08-28 | revenue | 226954000000 | us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax | 2024-10-09 | 0000909832-24-000049 |
| 2022-08-28 | net_income | 5844000000 | us-gaap:NetIncomeLoss | 2024-10-09 | 0000909832-24-000049 |
| 2022-08-28 | operating_cash_flow | 7392000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2024-10-09 | 0000909832-24-000049 |
| 2022-08-28 | capital_spending | 3891000000 | us-gaap:PaymentsToAcquirePropertyPlantAndEquipment | 2024-10-09 | 0000909832-24-000049 |
| 2022-08-28 | equity | 20642000000 | us-gaap:StockholdersEquity | 2023-10-11 | 0000909832-23-000042 |
| 2022-08-28 | roe_pct | 28.3% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2022-08-28 | owner_earnings | 3501000000 | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2023-09-03 | revenue | 242290000000 | us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax | 2025-10-08 | 0000909832-25-000101 |
| 2023-09-03 | net_income | 6292000000 | us-gaap:NetIncomeLoss | 2025-10-08 | 0000909832-25-000101 |
| 2023-09-03 | operating_cash_flow | 11068000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2025-10-08 | 0000909832-25-000101 |
| 2023-09-03 | capital_spending | 4323000000 | us-gaap:PaymentsToAcquirePropertyPlantAndEquipment | 2025-10-08 | 0000909832-25-000101 |
| 2023-09-03 | equity | 25058000000 | us-gaap:StockholdersEquity | 2026-10-07 | 0000909832-26-000093 |
| 2023-09-03 | roe_pct | 25.1% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2023-09-03 | owner_earnings | 6745000000 | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2024-09-01 | revenue | 254453000000 | us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax | 2026-10-07 | 0000909832-26-000093 |
| 2024-09-01 | net_income | 7367000000 | us-gaap:NetIncomeLoss | 2026-10-07 | 0000909832-26-000093 |
| 2024-09-01 | operating_cash_flow | 11339000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2026-10-07 | 0000909832-26-000093 |
| 2024-09-01 | capital_spending | 4710000000 | us-gaap:PaymentsToAcquirePropertyPlantAndEquipment | 2026-10-07 | 0000909832-26-000093 |
| 2024-09-01 | equity | 23622000000 | us-gaap:StockholdersEquity | 2026-10-07 | 0000909832-26-000093 |
| 2024-09-01 | roe_pct | 31.2% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2024-09-01 | owner_earnings | 6629000000 | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2025-08-31 | revenue | 275235000000 | us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax | 2026-10-07 | 0000909832-26-000093 |
| 2025-08-31 | net_income | 8099000000 | us-gaap:NetIncomeLoss | 2026-10-07 | 0000909832-26-000093 |
| 2025-08-31 | operating_cash_flow | 13335000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2026-10-07 | 0000909832-26-000093 |
| 2025-08-31 | capital_spending | 5498000000 | us-gaap:PaymentsToAcquirePropertyPlantAndEquipment | 2026-10-07 | 0000909832-26-000093 |
| 2025-08-31 | equity | 29164000000 | us-gaap:StockholdersEquity | 2026-10-07 | 0000909832-26-000093 |
| 2025-08-31 | roe_pct | 27.8% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2025-08-31 | owner_earnings | 7837000000 | operating_cash_flow − capital_spending (source tags above) | calculated | |
| 2026-08-30 | revenue | 303154000000 | us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax | 2026-10-07 | 0000909832-26-000093 |
| 2026-08-30 | net_income | 9226000000 | us-gaap:NetIncomeLoss | 2026-10-07 | 0000909832-26-000093 |
| 2026-08-30 | operating_cash_flow | 15817000000 | us-gaap:NetCashProvidedByUsedInOperatingActivities | 2026-10-07 | 0000909832-26-000093 |
| 2026-08-30 | capital_spending | 6435000000 | us-gaap:PaymentsToAcquirePropertyPlantAndEquipment | 2026-10-07 | 0000909832-26-000093 |
| 2026-08-30 | equity | 35803000000 | us-gaap:StockholdersEquity | 2026-10-07 | 0000909832-26-000093 |
| 2026-08-30 | roe_pct | 25.8% | NetIncomeLoss / StockholdersEquity × 100 | calculated | |
| 2026-08-30 | owner_earnings | 9382000000 | operating_cash_flow − capital_spending (source tags above) | calculated | |

ROE uses year-end equity; nonpositive equity makes ROE not known.
Owner earnings uses total capital spending, not estimated maintenance spending.
Threshold rationale: the course's 15% ROE floor screens persistent profitability; positive and growing owner earnings screen cash generation. These are design choices, not a valuation.
Missing input makes a check not known. No values are estimated.

Data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice.
