# Reusable build request

This request was drafted with AI assistance from Alex's instruction to complete Lab 18. It is not presented as independently written student work.

Build Lab 18 as a local project with a Codex skill named buffett-edgar and a bundled Python script. Read the FAskills financial-researcher SKILL.md and Buffett page as architecture/philosophy references, without installing FAskills. Follow the lab's SEC-only rules instead of the reference's paid data sources and price analysis.

For an input ticker, fetch SEC companyfacts with a caller-identifying User-Agent. Select the last five annual 10-K periods, label by fiscal-year-end date, require annual flow contexts, prefer the lab's primary tags with its fallback tags, and use the latest eligible filing for a repeated period. Print revenue, net income, operating cash flow, capital spending, equity, ROE, and owner earnings with tags and provenance. Compute ROE as net income divided by year-end equity and owner earnings as operating cash flow minus capex. Preserve not found and not known; never estimate absent inputs.

Compute the three Buffett checks in code. Have the AI read printed evidence and write a short business-only own/watch/pass memo using only printed numbers. Save it as Markdown. Build a Streamlit app with ticker input, net income and owner-earnings chart, financial table, checks, editable memo, numeric support flags, and the required disclosure under its title.

Validate every COST reference value. Run JPM and preserve absent capex and owner earnings. Prove the app flags an injected unsupported ROE. Save verification results and study notes covering the code explanation, progressive disclosure, limitations, proposed trust decision, and reflection. Keep everything local; do not post to GitHub or submit to Brightspace.
