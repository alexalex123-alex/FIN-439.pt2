# Lab 18 verification — November 3, 2026

Live SEC EDGAR companyfacts were downloaded for COST and JPM using the caller identity Alex supplied. The contact header was not saved. The cutoff for eligible filings is November 3, 2026. Retrieval timestamps, source URLs, source tags, filing dates, accessions, and SHA-256 snapshot hashes are recorded in the report JSON and raw-snapshot sidecars.

| Requirement / probe | Observed result |
|---|---|
| COST reference table | Every amount, fiscal-year-end date, and rounded ROE matches the course answer across all five years |
| COST ROE floor | Pass every year |
| COST positive owner earnings | Pass every year |
| COST first-to-last owner earnings growth | Pass; the intervening decline remains visible |
| Chart | Owner earnings and net income both increase from the first to last fiscal year; browser rendering inspected |
| JPM capex | Not found under either permitted tag in every selected year |
| JPM owner earnings | Not found; no zero or estimate substituted |
| JPM owner-earnings checks | Both not known |
| JPM ROE floor | Fail; at least one selected year is below the course floor |
| Saved COST and JPM memos | No unsupported numeric tokens |
| Injected 40.0% in COST memo | App shows unsupported-number error; clean saved memo remains unchanged |
| Annual selection | A synthetic later-filed quarter is ignored; a future filing beyond the cutoff is ignored |
| Latest repeat | A controlled later eligible annual observation replaces the older value |
| Fallback tag | The permitted revenue fallback is used when the preferred tag lacks that period |
| Nonpositive equity | ROE becomes not known |
| Incomplete window | Checks remain not known rather than certifying fewer years |
| Snapshot reproducibility | Recalculating both downloaded raw snapshots reproduces the report JSON, with matching hashes |
| Contact missing in app | Clear error; saved evidence remains displayed |

Automated result: **9 tests passed** using `python -m pytest tests -q`. See `reports/test-results.txt`. Streamlit emitted dependency deprecation warnings about an internal pandas operation; no application exceptions occurred. `requirements-tested.txt` records the tested environment.

The browser view was also inspected: required disclosure immediately under the title, all COST checks passing, and the two-series chart visible. AppTest additionally verifies the financial table, both memo states, and the injected-number error.

The skill frontmatter validator is run separately from financial/app verification. It checks packaging and naming, not the correctness of an investment judgment.

This record does **not** claim the student completed partner discussions, the no-AI explanation, or the Brightspace quiz. These remain listed in `LEARNING_NOTES.md`. Nothing was uploaded to GitHub, per the student's instruction.

The fresh-chat comparison was subsequently recorded from Alex's supplied output in LEARNING_NOTES.md. It uses average equity rather than the lab's year-end equity. Its separate calculation-input file was not supplied or independently verified.

