from pathlib import Path
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[1]


def test_cost_app_and_live_memo_guard():
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    assert not app.exception
    assert [m.value for m in app.metric] == ["PASS", "PASS", "PASS"]
    assert len(app.dataframe) == 1
    assert app.dataframe[0].value.shape == (5, 8)
    assert len(app.get("arrow_vega_lite_chart")) + len(app.get("vega_lite_chart")) >= 1
    assert not app.error
    assert app.success
    app.text_area[0].set_value(app.text_area[0].value + "\nInjected ROE: 40.0%.").run()
    assert not app.exception
    assert any("40.0%" in error.value for error in app.error)


def test_jpm_app_gaps_and_no_unsupported_numbers():
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    app.text_input[0].set_value("JPM").run()
    assert not app.exception
    assert [m.value for m in app.metric] == ["FAIL", "NOT KNOWN", "NOT KNOWN"]
    assert (app.dataframe[0].value["Capital Spending"] == "not found").all()
    assert (app.dataframe[0].value["Owner Earnings"] == "not found").all()
    assert not app.error


def test_bad_contact_is_reported_without_replacing_saved_data():
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    app.text_input[1].set_value("")
    app.button[0].click().run()
    assert not app.exception
    assert any("SEC_USER_AGENT" in error.value for error in app.error)
    assert [m.value for m in app.metric] == ["PASS", "PASS", "PASS"]
