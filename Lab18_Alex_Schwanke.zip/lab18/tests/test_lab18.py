import copy
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("edgar", ROOT / ".agents/skills/buffett-edgar/scripts/edgar.py")
edgar = importlib.util.module_from_spec(spec)
spec.loader.exec_module(edgar)


def load_report(ticker):
    return json.loads((ROOT / "reports" / f"{ticker}.json").read_text(encoding="utf-8"))


def test_live_cost_against_independent_lab_reference():
    report = load_report("COST")
    reference = json.loads((ROOT / "reference/cost_lab_reference.json").read_text())
    assert len(report["rows"]) == 5
    for actual, expected in zip(report["rows"], reference["rows"]):
        for key, value in zip(reference["columns"], expected):
            if key == "fiscal_year_end":
                assert actual[key] == value
            elif key == "roe_pct":
                assert round(actual[key], 1) == value
            else:
                assert actual[key] / 1_000_000 == value
    assert set(report["checks"].values()) == {"pass"}


def test_live_jpm_missing_inputs_remain_missing():
    report = load_report("JPM")
    assert len(report["rows"]) == 5
    for row in report["rows"]:
        assert row["capital_spending"] is None
        assert row["owner_earnings"] is None
        assert row["owner_earnings_status"] == "not found"
    assert list(report["checks"].values()) == ["fail", "not known", "not known"]


def test_memos_and_injected_number():
    for ticker in ("COST", "JPM"):
        report = load_report(ticker)
        memo = (ROOT / f"reports/{ticker}_memo.md").read_text(encoding="utf-8")
        assert edgar.unsupported_numbers(memo, edgar.render_report(report)) == []
    printed = edgar.render_report(load_report("COST"))
    assert edgar.unsupported_numbers("ROE is 40.0%.", printed) == [{"token": "40.0%", "line": 1}]
    assert edgar.unsupported_numbers("Profit was 987654321.5.", printed)
    assert edgar.unsupported_numbers("ROE is .5%.", printed)
    assert edgar.unsupported_numbers("ROE is 25.8%.", printed) == []
    assert edgar.unsupported_numbers("ROE is 25.8%.", "25.8")  # Percent unit matters.


def test_latest_filing_tag_fallback_and_annual_context():
    company = json.loads((ROOT / "reports/raw/COST_companyfacts.json").read_text())
    end, start = "2026-08-30", "2025-09-01"
    gaap = company["facts"]["us-gaap"]
    revenue = gaap[edgar.TAGS["revenue"][0]]["units"]["USD"]
    # A later-filed quarter and a future-filed annual observation must be ignored.
    revenue += [dict(start="2026-06-01", end=end, val=1, form="10-K", filed="2026-10-08"),
                dict(start=start, end=end, val=2, form="10-K", filed="2027-01-01")]
    row = edgar.build_row(company, start, end, "2026-11-03")
    assert row["revenue"] == 303154000000
    revenue.append(dict(start=start, end=end, val=303155000000, form="10-K", filed="2026-10-09", accn="test"))
    assert edgar.build_row(company, start, end, "2026-11-03")["revenue"] == 303155000000
    # Tag priority falls back when primary is missing for this specific period.
    gaap["Revenues"] = {"units": {"USD": copy.deepcopy(revenue)}}
    gaap[edgar.TAGS["revenue"][0]]["units"]["USD"] = [f for f in revenue if f["end"] != end]
    assert edgar.build_row(company, start, end, "2026-11-03")["sources"]["revenue"]["tag"] == "us-gaap:Revenues"


def test_nonpositive_equity_and_missing_year():
    company = json.loads((ROOT / "reports/raw/COST_companyfacts.json").read_text())
    facts = company["facts"]["us-gaap"]["StockholdersEquity"]["units"]["USD"]
    for fact in facts:
        if fact["end"] == "2026-08-30":
            fact["val"] = -1
    row = edgar.build_row(company, "2025-09-01", "2026-08-30", "2026-11-03")
    assert row["roe_pct"] is None and row["roe_status"] == "not known"
    assert set(edgar.checks([row]).values()) == {"not known"}


def test_snapshot_recomputes_report_and_has_correct_hash():
    import hashlib
    for ticker in ("COST", "JPM"):
        report = load_report(ticker)
        raw = (ROOT / f"reports/raw/{ticker}_companyfacts.json").read_bytes()
        assert hashlib.sha256(raw).hexdigest() == report["provenance"]["sha256"]
        recomputed = edgar.analyze(json.loads(raw), ticker, report["as_of"], report["provenance"])
        assert recomputed == report
