# Lab 18 — explanations and student activities

These notes and proposed reflection are AI-assisted study material. Read and explain them in your own words; they do not certify that the partner activities happened.

## Define and represent

**Question:** Can an investor's philosophy become a skill your AI runs the same way every time—every number computed by code from the 10-K, the judgment the model's?

Code can calculate return on equity and test whether owner earnings are positive. Code cannot establish from this table alone that a competitive advantage will last or that management will allocate capital well. Those are judgments requiring additional qualitative evidence and uncertainty.

The 15% floor is retained because it is the lab's explicit persistence screen. It is a design choice: high reported ROE alone cannot establish quality, since leverage, accounting choices, and the equity denominator affect it. Positive owner earnings and first-to-last growth similarly screen cash generation without establishing valuation. First-to-last growth is not the same as growth every year: COST has an intervening decline.

## Explain the actual code

Open `.agents/skills/buffett-edgar/scripts/edgar.py` at `build_row` for the required no-AI partner exercise.

1. `sources = ...` calls `select_fact` for each required financial input and retains its provenance rather than only its value.
2. `row = ...` records the annual start and fiscal-year-end date.
3. `row.update(...)` extracts the raw values; a missing tag remains `None`, not zero.
4. The next assignments name the inputs for each formula.
5. `roe_pct` divides net income by equity and converts to percent only if both inputs exist and equity is positive. Otherwise its value stays `None` and the status is `not known`.
6. `owner_earnings` subtracts capital spending only when both inputs exist. A missing capex value leaves owner earnings `None`, rendered as `not found`.
7. Status fields make the distinction explicit, and the function returns the complete row.

If your partner asks where “not found” originates, point to `select_fact`'s final return after both permitted tags lack an eligible observation. The display formatter turns the absent value into text. No number is guessed. `checks` turns any absent required input into `not known`.

The surrounding selection code checks form, filing cutoff, USD units, exact period, and annual duration. It sorts eligible repeats by filing date and accession. It avoids relying on `fy`, because comparative observations can carry the fiscal-year label of a later filing. The source ledger shows the actual dates and tags.

## What an agent skill is and why metadata loads first

A skill is a folder of reusable instructions and resources. Its `SKILL.md` starts with a name and description that let the AI decide when it applies. Loading just this metadata during discovery keeps unrelated procedures out of context. Once the workflow is selected, the AI reads the instructions and uses the bundled script. The folder gives repeated requests the same data definitions and calculations without pretending judgment becomes deterministic.

Numbers belong in code because period filtering, tag selection, arithmetic, and missing-input rules can be tested and traced. The model judges the business using the resulting evidence. Agreement with another AI is not independent validation; matching the reference and inspecting the source contexts are stronger checks.

## Proposed reflection and decision — review in your own words

The skill makes data selection, formulas, missing-value handling, printed evidence, and numerical checks repeatable. The model still chooses how to weigh consistency, business durability, and evidence gaps, so memo wording and judgment can vary.

“Not found” is better than an estimate here because an estimate would conceal a data gap and allow a pass/fail result to look sourced when it is not. JPM demonstrates this: missing capex prevents the specified owner-earnings calculation and leaves its related checks unknown.

I would trust COST's computed screen after validation, while treating the business verdict as provisional. The screen shows persistent profitability and positive owner earnings, but does not establish moat durability, management quality, a fair price, or a future return. The memo's trust line is a proposed answer for Alex to review, not a claim that Alex already endorsed it.

## Activities Alex must still perform

- Explain one computable item and one judgment item to your partner, then swap.
- Explain `build_row` line by line with no AI assistance during the explanation; have your partner ask about missing values, then swap.
- Review the fresh-chat comparison below, recorded from the output Alex supplied. Its separately named full-answer document was not attached, so the underlying average-equity inputs have not been independently verified here.
- Discuss why the model initially sees only the skill's name and description; explain what stays repeatable and what remains judgment.
- Review the proposed trust decision and reflection, then complete the individual Brightspace quiz. The lab requests GitHub file links. No GitHub posting was done, per Alex's explicit instruction; a local ZIP is not a published GitHub link.

## Fresh-chat comparison — output supplied by Alex

The supplied answer says Costco fits a Buffett-style business and explicitly calculates ROE as net income divided by average beginning-and-ending shareholders' equity. The lab skill uses net income divided by year-end equity. These different denominators explain why the results are not directly interchangeable; a difference alone is not evidence that either calculation is fabricated.

| Fiscal year end | Skill ROE | Fresh-chat ROE | Source / explanation of difference |
|---|---:|---|---|
| 2022-08-28 | 28.3% | 30.59% | Year-end equity versus average equity |
| 2023-09-03 | 25.1% | 27.54% | Year-end equity versus average equity |
| 2024-09-01 | 31.2% | 30.27% | Year-end equity versus average equity |
| 2025-08-31 | 27.8% | 30.69% | Year-end equity versus average equity |
| 2026-08-30 | 25.8% | 28.40% | Year-end equity versus average equity |

The fresh answer labels fiscal years but does not list fiscal-year-end dates. It cites Berkshire's acquisition criteria for its business-quality framework and a Costco annual filing whose URL identifies the fiscal year ending September 3, 2023. That displayed filing link alone does not establish all of the later-year calculations. The answer mentions a separate file containing calculation inputs and claim-by-claim sources, but that file was not supplied here. Its comments about member loyalty, debt, and special dividends are claims from the comparison answer, not additional conclusions verified by this lab's financial screen.

**Comparison conclusion:** Both outputs view Costco favorably as a business, but the skill enforces the lab's precise ROE definition and preserves a row-level source ledger. I would use the skill's ROEs for this assignment and inspect the fresh answer's beginning/ending equity inputs before treating its alternative ROEs as verified. The key lesson is to compare definitions, periods, and source coverage before comparing numerical agreement.
