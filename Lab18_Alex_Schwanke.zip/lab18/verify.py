"""Run meaningful numerical/source checks with the standard library, plus app checks if installed."""
import importlib.util
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parent
namespace = runpy.run_path(str(ROOT / "tests/test_lab18.py"))
tests = [(name, function) for name, function in namespace.items() if name.startswith("test_")]
for name, function in tests:
    function()
    print("PASS", name)
print(f"{len(tests)} evidence/calculation checks passed")
if importlib.util.find_spec("streamlit"):
    app_namespace = runpy.run_path(str(ROOT / "tests/test_app.py"))
    for name, function in app_namespace.items():
        if name.startswith("test_"):
            function()
            print("PASS", name)
else:
    print("SKIP Streamlit app checks: install requirements.txt to run these.")
